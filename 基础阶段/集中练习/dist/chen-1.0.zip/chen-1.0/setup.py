from distutils.core import setup

setup(name="chen", version="1.0", description="chen's module", author="chen", py_modules=['Testmsg.sendmsg','Testmsg.recvmsg'])

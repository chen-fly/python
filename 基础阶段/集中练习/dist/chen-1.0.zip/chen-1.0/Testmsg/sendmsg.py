def test2():
    print("---send message test2---")

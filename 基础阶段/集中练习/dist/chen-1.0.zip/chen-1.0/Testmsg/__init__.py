__all__ = ["sendmsg"]
# python2可以使用下面导入
#import sendmsg
# python2/3均可使用下面导入
from . import sendmsg
print("-----hahahah    1-------")
